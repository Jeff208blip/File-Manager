import { z } from "zod";
import { 
  users, technicians, bookings, payments, reviews,
  insertUserSchema, insertTechnicianSchema, insertBookingSchema,
  insertPaymentSchema, insertReviewSchema 
} from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    register: {
      method: "POST" as const,
      path: "/api/auth/register" as const,
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      }
    },
    login: {
      method: "POST" as const,
      path: "/api/auth/login" as const,
      input: z.object({ email: z.string(), password: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.object({ message: z.string() }),
      }
    },
    me: {
      method: "GET" as const,
      path: "/api/auth/me" as const,
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.object({ message: z.string() }),
      }
    },
    logout: {
      method: "POST" as const,
      path: "/api/auth/logout" as const,
      responses: {
        200: z.object({ message: z.string() })
      }
    }
  },
  technicians: {
    list: {
      method: "GET" as const,
      path: "/api/technicians" as const,
      input: z.object({ search: z.string().optional(), category: z.string().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof technicians.$inferSelect>()),
      }
    },
    get: {
      method: "GET" as const,
      path: "/api/technicians/:id" as const,
      responses: {
        200: z.custom<typeof technicians.$inferSelect>(),
        404: errorSchemas.notFound,
      }
    },
    create: {
      method: "POST" as const,
      path: "/api/technicians" as const,
      input: insertTechnicianSchema,
      responses: {
        201: z.custom<typeof technicians.$inferSelect>(),
        400: errorSchemas.validation,
      }
    },
    update: {
      method: "PUT" as const,
      path: "/api/technicians/:id" as const,
      input: insertTechnicianSchema.partial(),
      responses: {
        200: z.custom<typeof technicians.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      }
    }
  },
  bookings: {
    list: {
      method: "GET" as const,
      path: "/api/bookings" as const,
      responses: {
        200: z.array(z.custom<typeof bookings.$inferSelect>()),
      }
    },
    create: {
      method: "POST" as const,
      path: "/api/bookings" as const,
      input: insertBookingSchema,
      responses: {
        201: z.custom<typeof bookings.$inferSelect>(),
        400: errorSchemas.validation,
      }
    },
    updateStatus: {
      method: "PATCH" as const,
      path: "/api/bookings/:id/status" as const,
      input: z.object({ status: z.string() }),
      responses: {
        200: z.custom<typeof bookings.$inferSelect>(),
        404: errorSchemas.notFound,
      }
    },
    pay: {
      method: "POST" as const,
      path: "/api/bookings/:id/pay" as const,
      input: z.object({ phone: z.string(), amount: z.number() }),
      responses: {
        200: z.object({ message: z.string(), transactionId: z.string() }),
        400: errorSchemas.validation,
      }
    }
  },
  reviews: {
    list: {
      method: "GET" as const,
      path: "/api/technicians/:id/reviews" as const,
      responses: {
        200: z.array(z.custom<typeof reviews.$inferSelect>()),
      }
    },
    create: {
      method: "POST" as const,
      path: "/api/technicians/:id/reviews" as const,
      input: insertReviewSchema.omit({ technicianId: true, userId: true }),
      responses: {
        201: z.custom<typeof reviews.$inferSelect>(),
        400: errorSchemas.validation,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
