import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Basic session setup for mock auth
  app.use(session({
    secret: "fixnearme-secret",
    resave: false,
    saveUninitialized: false,
    store: new MemoryStore({ checkPeriod: 86400000 }),
    cookie: { secure: process.env.NODE_ENV === "production" }
  }));

  // Auth Routes
  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existingUser = await storage.getUserByEmail(input.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already exists" });
      }
      const user = await storage.createUser(input);
      (req.session as any).userId = user.id;
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.auth.login.path, async (req, res) => {
    try {
      const { email, password } = api.auth.login.input.parse(req.body);
      const user = await storage.getUserByEmail(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      (req.session as any).userId = user.id;
      res.status(200).json(user);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.get(api.auth.me.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    res.status(200).json(user);
  });

  app.post(api.auth.logout.path, (req, res) => {
    req.session.destroy(() => {
      res.status(200).json({ message: "Logged out" });
    });
  });

  // Technicians Routes
  app.get(api.technicians.list.path, async (req, res) => {
    const techs = await storage.getTechnicians();
    // simple filtering could be added here
    res.status(200).json(techs);
  });

  app.get(api.technicians.get.path, async (req, res) => {
    const tech = await storage.getTechnician(Number(req.params.id));
    if (!tech) return res.status(404).json({ message: "Technician not found" });
    res.status(200).json(tech);
  });

  app.post(api.technicians.create.path, async (req, res) => {
    try {
      const input = api.technicians.create.input.parse(req.body);
      const tech = await storage.createTechnician(input);
      res.status(201).json(tech);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.technicians.update.path, async (req, res) => {
    try {
      const input = api.technicians.update.input.parse(req.body);
      const tech = await storage.updateTechnician(Number(req.params.id), input);
      if (!tech) return res.status(404).json({ message: "Technician not found" });
      res.status(200).json(tech);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Bookings Routes
  app.get(api.bookings.list.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) return res.status(401).json({ message: "Not authenticated" });
    
    const user = await storage.getUser(userId);
    let userBookings = [];
    if (user?.role === 'technician') {
      const tech = await storage.getTechnicianByUserId(userId);
      if (tech) userBookings = await storage.getTechnicianBookings(tech.id);
    } else {
      userBookings = await storage.getUserBookings(userId);
    }
    
    res.status(200).json(userBookings);
  });

  app.post(api.bookings.create.path, async (req, res) => {
    try {
      const input = api.bookings.create.input.parse(req.body);
      // extend with coerce for dates
      const booking = await storage.createBooking({
        ...input,
        date: new Date(input.date)
      });
      res.status(201).json(booking);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch(api.bookings.updateStatus.path, async (req, res) => {
    try {
      const input = api.bookings.updateStatus.input.parse(req.body);
      const booking = await storage.updateBookingStatus(Number(req.params.id), input.status);
      res.status(200).json(booking);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.bookings.pay.path, async (req, res) => {
    try {
      const input = api.bookings.pay.input.parse(req.body);
      // Mock M-Pesa STK Push
      const transactionId = `MPESA${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
      
      await storage.createPayment({
        transactionId,
        bookingId: Number(req.params.id),
        amount: input.amount.toString(),
        phone: input.phone,
        status: "completed"
      });
      
      res.status(200).json({ message: "Payment successful", transactionId });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Reviews
  app.get(api.reviews.list.path, async (req, res) => {
    const reviewsList = await storage.getTechnicianReviews(Number(req.params.id));
    res.status(200).json(reviewsList);
  });

  app.post(api.reviews.create.path, async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) return res.status(401).json({ message: "Not authenticated" });
      
      const input = api.reviews.create.input.parse(req.body);
      const review = await storage.createReview({
        ...input,
        userId,
        technicianId: Number(req.params.id)
      });
      res.status(201).json(review);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // Call seed database
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingUsers = await storage.getUserByEmail("test@example.com");
  if (!existingUsers) {
    const user = await storage.createUser({
      name: "Test User",
      email: "test@example.com",
      password: "password123",
      phone: "0799153149",
      location: "Westlands, Nairobi",
      role: "user"
    });

    const techUser = await storage.createUser({
      name: "John Plumber",
      email: "john@example.com",
      password: "password123",
      phone: "0799153149",
      location: "Kilimani, Nairobi",
      role: "technician"
    });

    const tech = await storage.createTechnician({
      userId: techUser.id,
      name: "John Plumber",
      phone: "0799153149",
      whatsapp: "0799153149",
      services: ["Plumber", "Handyman"],
      rating: "4.8",
      location: "Kilimani, Nairobi",
      latitude: "-1.2891",
      longitude: "36.7844",
      serviceRadius: 15,
      priceRange: "Ksh 1000 - 3000",
      availability: true
    });

    const techUser2 = await storage.createUser({
      name: "Sarah Electrician",
      email: "sarah@example.com",
      password: "password123",
      phone: "0799153149",
      location: "Kasarani, Nairobi",
      role: "technician"
    });

    await storage.createTechnician({
      userId: techUser2.id,
      name: "Sarah Electrician",
      phone: "0799153149",
      whatsapp: "0799153149",
      services: ["Electrician", "CCTV Installation"],
      rating: "4.9",
      location: "Kasarani, Nairobi",
      latitude: "-1.2222",
      longitude: "36.8992",
      serviceRadius: 20,
      priceRange: "Ksh 1500 - 5000",
      availability: true
    });
    
    await storage.createReview({
      userId: user.id,
      technicianId: tech.id,
      rating: 5,
      comment: "Very professional and fast service. Fixed my leaking sink in under 30 mins."
    });
  }
}
