import { Star, MapPin, Wrench } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface TechnicianCardProps {
  technician: {
    id: number;
    name: string;
    services: string[];
    rating: string | number;
    location: string;
    priceRange: string | null;
    profileImage: string | null;
    availability: boolean | null;
  }
}

export function TechnicianCard({ technician }: TechnicianCardProps) {
  const rating = Number(technician.rating).toFixed(1);
  const isAvailable = technician.availability;

  return (
    <div className="bg-white rounded-2xl p-5 border border-border/50 shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300 group flex flex-col h-full">
      <div className="flex gap-4 mb-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full bg-secondary/50 border-2 border-white shadow-sm overflow-hidden flex items-center justify-center">
            {technician.profileImage ? (
              <img src={technician.profileImage} alt={technician.name} className="w-full h-full object-cover" />
            ) : (
              <Wrench className="w-8 h-8 text-muted-foreground" />
            )}
          </div>
          <div className={`absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-white ${isAvailable ? 'bg-accent' : 'bg-destructive'}`} 
               title={isAvailable ? "Available" : "Busy"} />
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-display font-bold text-lg text-foreground truncate group-hover:text-primary transition-colors">
            {technician.name}
          </h3>
          <div className="flex items-center text-sm text-muted-foreground mt-1">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400 mr-1" />
            <span className="font-medium text-foreground">{rating}</span>
            <span className="mx-2">•</span>
            <MapPin className="w-3.5 h-3.5 mr-1" />
            <span className="truncate">{technician.location}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-5 mt-auto">
        {technician.services.slice(0, 3).map((service) => (
          <Badge key={service} variant="secondary" className="bg-secondary/50 text-xs font-normal">
            {service}
          </Badge>
        ))}
        {technician.services.length > 3 && (
          <Badge variant="secondary" className="bg-secondary/50 text-xs font-normal">
            +{technician.services.length - 3} more
          </Badge>
        )}
      </div>

      <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/50">
        <div className="text-sm font-medium text-foreground">
          {technician.priceRange || 'Price on request'}
        </div>
        <Link href={`/technician/${technician.id}`}>
          <Button size="sm" className="bg-primary text-white rounded-full px-5 shadow-md shadow-primary/20 hover:shadow-lg hover:-translate-y-0.5 transition-all">
            View Profile
          </Button>
        </Link>
      </div>
    </div>
  );
}
