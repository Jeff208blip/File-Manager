import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Wrench, Search, User as UserIcon, LogOut, Menu } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    logout();
  };

  const NavLinks = () => (
    <>
      <Link href="/search" className={`text-sm font-medium transition-colors hover:text-primary ${location === '/search' ? 'text-primary' : 'text-muted-foreground'}`}>
        Find Services
      </Link>
      {user ? (
        <>
          <Link href="/dashboard" className={`text-sm font-medium transition-colors hover:text-primary ${location === '/dashboard' ? 'text-primary' : 'text-muted-foreground'}`}>
            Dashboard
          </Link>
          <Button variant="ghost" onClick={handleLogout} className="text-sm font-medium text-muted-foreground hover:text-destructive">
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </>
      ) : (
        <Link href="/login">
          <Button className="bg-primary text-white hover:bg-primary/90 rounded-full px-6 shadow-md shadow-primary/20 hover:shadow-lg transition-all hover:-translate-y-0.5">
            Log In
          </Button>
        </Link>
      )}
    </>
  );

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/50">
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-lg supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="bg-primary p-2 rounded-xl text-white group-hover:scale-105 transition-transform shadow-sm">
              <Wrench className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-primary">FixNearMe</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <NavLinks />
          </nav>

          {/* Mobile Nav */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent className="flex flex-col gap-6 pt-12">
                <NavLinks />
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col">
        {children}
      </main>

      <footer className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Wrench className="w-6 h-6 text-accent" />
              <span className="font-display font-bold text-2xl">FixNearMe</span>
            </div>
            <p className="text-primary-foreground/70 text-sm">
              Nairobi's trusted marketplace for local home services and repairs. 
              Find the right professional in minutes.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4 font-display text-lg">Services</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/70">
              <li><Link href="/search?category=Plumbing" className="hover:text-accent transition-colors">Plumbing</Link></li>
              <li><Link href="/search?category=Electrical" className="hover:text-accent transition-colors">Electrical</Link></li>
              <li><Link href="/search?category=Carpentry" className="hover:text-accent transition-colors">Carpentry</Link></li>
              <li><Link href="/search?category=Cleaning" className="hover:text-accent transition-colors">Cleaning</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 font-display text-lg">Company</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/70">
              <li><Link href="/about" className="hover:text-accent transition-colors">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-accent transition-colors">Contact</Link></li>
              <li><Link href="/terms" className="hover:text-accent transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 font-display text-lg">Contact Us</h4>
            <p className="text-sm text-primary-foreground/70 mb-2">support@fixnearme.co.ke</p>
            <p className="text-sm text-primary-foreground/70 mb-4">0799153149</p>
            <div className="pt-4 border-t border-primary-foreground/20">
              <p className="text-xs text-primary-foreground/50">Created by developer Karanja</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
