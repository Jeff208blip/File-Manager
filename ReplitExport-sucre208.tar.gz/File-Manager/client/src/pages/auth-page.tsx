import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wrench, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function AuthPage() {
  const [_, setLocation] = useLocation();
  const { user, login, register, isLoggingIn, isRegistering } = useAuth();
  
  if (user) {
    setLocation("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen flex bg-slate-50">
      <div className="flex-1 flex flex-col justify-center items-center p-4">
        <div className="w-full max-w-md">
          <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
          </Link>
          
          <div className="bg-white rounded-3xl p-8 shadow-2xl shadow-primary/5 border border-slate-100">
            <div className="flex justify-center mb-6">
              <div className="bg-primary p-3 rounded-2xl text-white shadow-lg">
                <Wrench className="w-8 h-8" />
              </div>
            </div>
            <h1 className="text-2xl font-display font-bold text-center mb-8">Welcome to FixNearMe</h1>

            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 h-12 bg-slate-100 rounded-xl p-1">
                <TabsTrigger value="login" className="rounded-lg font-medium data-[state=active]:shadow-sm">Log In</TabsTrigger>
                <TabsTrigger value="register" className="rounded-lg font-medium data-[state=active]:shadow-sm">Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <LoginForm onSubmit={login} isPending={isLoggingIn} />
              </TabsContent>
              
              <TabsContent value="register">
                <RegisterForm onSubmit={register} isPending={isRegistering} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
      
      {/* Visual side for larger screens */}
      <div className="hidden lg:flex flex-1 relative bg-primary items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-40 mix-blend-overlay">
          {/* landing page hero handy person working */}
          <img 
            src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=1200&h=1600&fit=crop" 
            alt="Handyman" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10 p-16 max-w-2xl text-white text-center">
          <h2 className="text-5xl font-display font-bold leading-tight mb-6 text-balance">
            Join the trusted network of professionals and clients.
          </h2>
          <p className="text-xl text-white/80 text-balance">
            Secure payments, verified profiles, and reliable service delivery across Nairobi.
          </p>
        </div>
      </div>
    </div>
  );
}

function LoginForm({ onSubmit, isPending }: { onSubmit: any, isPending: boolean }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ email, password });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Email</Label>
        <Input required type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} className="h-12 bg-slate-50" />
      </div>
      <div className="space-y-2">
        <Label>Password</Label>
        <Input required type="password" value={password} onChange={e => setPassword(e.target.value)} className="h-12 bg-slate-50" />
      </div>
      <Button type="submit" className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 mt-4 shadow-lg shadow-primary/20" disabled={isPending}>
        {isPending ? "Logging in..." : "Log In"}
      </Button>
    </form>
  );
}

function RegisterForm({ onSubmit, isPending }: { onSubmit: any, isPending: boolean }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("user");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, email, password, role });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Full Name</Label>
        <Input required placeholder="John Doe" value={name} onChange={e => setName(e.target.value)} className="h-12 bg-slate-50" />
      </div>
      <div className="space-y-2">
        <Label>Email</Label>
        <Input required type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} className="h-12 bg-slate-50" />
      </div>
      <div className="space-y-2">
        <Label>Password</Label>
        <Input required type="password" value={password} onChange={e => setPassword(e.target.value)} className="h-12 bg-slate-50" />
      </div>
      <div className="space-y-2 pb-2">
        <Label>I want to...</Label>
        <div className="grid grid-cols-2 gap-4 mt-2">
          <label className={`cursor-pointer border-2 rounded-xl p-4 text-center transition-all ${role === 'user' ? 'border-primary bg-primary/5 text-primary' : 'border-slate-200 text-slate-500'}`}>
            <input type="radio" className="sr-only" checked={role === 'user'} onChange={() => setRole('user')} />
            <div className="font-semibold">Hire Services</div>
          </label>
          <label className={`cursor-pointer border-2 rounded-xl p-4 text-center transition-all ${role === 'technician' ? 'border-primary bg-primary/5 text-primary' : 'border-slate-200 text-slate-500'}`}>
            <input type="radio" className="sr-only" checked={role === 'technician'} onChange={() => setRole('technician')} />
            <div className="font-semibold">Offer Services</div>
          </label>
        </div>
      </div>
      <Button type="submit" className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20" disabled={isPending}>
        {isPending ? "Creating Account..." : "Create Account"}
      </Button>
    </form>
  );
}
