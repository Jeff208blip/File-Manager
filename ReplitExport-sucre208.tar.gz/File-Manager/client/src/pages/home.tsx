import { useState } from "react";
import { useLocation, Link } from "wouter";
import { Search, PenTool, Zap, Droplets, Wrench, ArrowRight } from "lucide-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTechnicians } from "@/hooks/use-technicians";
import { TechnicianCard } from "@/components/technician-card";
import { motion } from "framer-motion";

const CATEGORIES = [
  { name: "Plumbing", icon: Droplets, color: "bg-blue-100 text-blue-600" },
  { name: "Electrical", icon: Zap, color: "bg-amber-100 text-amber-600" },
  { name: "Carpentry", icon: Wrench, color: "bg-orange-100 text-orange-600" },
  { name: "General Repair", icon: PenTool, color: "bg-purple-100 text-purple-600" },
];

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [, setLocation] = useLocation();
  const { data: technicians, isLoading } = useTechnicians();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative pt-24 pb-32 overflow-hidden">
        {/* Background Image with Wash */}
        <div className="absolute inset-0 z-0">
          {/* landing page hero handy person working */}
          <img 
            src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=1920&h=1080&fit=crop" 
            alt="Hero background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary/80 backdrop-blur-sm mix-blend-multiply"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
        </div>

        <div className="container relative z-10 mx-auto px-4 flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge className="mb-6 bg-accent/20 text-accent hover:bg-accent/30 border-accent/30 backdrop-blur-md px-4 py-1.5 rounded-full text-sm font-medium">
              #1 Service Marketplace in Nairobi
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-6 leading-tight text-balance">
              Find reliable professionals for any home repair.
            </h1>
            <p className="text-lg md:text-xl text-white/80 mb-10 text-balance max-w-2xl mx-auto">
              Connect with vetted, top-rated technicians in your neighborhood. Quick, affordable, and trustworthy.
            </p>

            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3 w-full max-w-2xl mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                <Input 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="What service do you need?" 
                  className="h-14 pl-12 rounded-2xl bg-white/95 border-white/20 shadow-xl text-lg text-foreground focus-visible:ring-accent"
                />
              </div>
              <Button type="submit" size="lg" className="h-14 px-8 rounded-2xl bg-accent hover:bg-accent/90 text-white font-bold text-lg shadow-lg shadow-accent/25 hover:shadow-xl hover:-translate-y-0.5 transition-all">
                Search
              </Button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-10">
            <div>
              <h2 className="text-3xl font-display font-bold text-foreground">Popular Services</h2>
              <p className="text-muted-foreground mt-2">Find what you need instantly</p>
            </div>
            <Link href="/search" className="hidden sm:flex items-center text-primary font-medium hover:underline">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {CATEGORIES.map((cat, i) => (
              <motion.div 
                key={cat.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link href={`/search?category=${cat.name}`}>
                  <div className="bg-white rounded-2xl p-6 border border-border hover:border-primary/20 hover:shadow-xl transition-all group cursor-pointer text-center flex flex-col items-center">
                    <div className={`w-16 h-16 rounded-2xl ${cat.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <cat.icon className="w-8 h-8" />
                    </div>
                    <h3 className="font-display font-bold text-lg group-hover:text-primary transition-colors">{cat.name}</h3>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Top Technicians */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-display font-bold text-foreground mb-2">Top Rated Technicians</h2>
          <p className="text-muted-foreground mb-10">Highly recommended professionals near you</p>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="bg-white/50 animate-pulse rounded-2xl h-[280px]"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {technicians?.slice(0, 4).map((tech, i) => (
                <motion.div
                  key={tech.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <TechnicianCard technician={tech} />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}

// A simple Badge component since we didn't extract Shadcn badge file explicitly
function Badge({ children, className }: { children: React.ReactNode, className?: string }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${className}`}>
      {children}
    </span>
  );
}
