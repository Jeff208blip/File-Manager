import { useState } from "react";
import { Layout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { useBookings, useUpdateBookingStatus, usePayBooking } from "@/hooks/use-bookings";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Calendar, CheckCircle2, Clock, MapPin, DollarSign, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function DashboardPage() {
  const { user } = useAuth();
  const { data: bookings, isLoading } = useBookings();
  
  if (!user) return <Layout><div className="text-center py-20">Please login to view your dashboard.</div></Layout>;

  return (
    <Layout>
      <div className="bg-primary pb-32 pt-12 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-display font-bold mb-2">Welcome, {user.name}</h1>
          <p className="text-primary-foreground/80">Manage your {user.role === 'technician' ? 'work and jobs' : 'service requests'}.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-20 pb-20">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-6 md:p-10 min-h-[500px]">
          <h2 className="text-2xl font-display font-bold mb-8">
            {user.role === 'technician' ? 'My Jobs' : 'My Bookings'}
          </h2>

          {isLoading ? (
            <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
          ) : bookings?.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              <Calendar className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No bookings found.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {bookings?.map(booking => (
                <BookingCard key={booking.id} booking={booking} userRole={user.role} />
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function BookingCard({ booking, userRole }: { booking: any, userRole: string }) {
  const updateStatus = useUpdateBookingStatus();
  const { toast } = useToast();

  const handleStatus = async (status: string) => {
    try {
      await updateStatus.mutateAsync({ id: booking.id, status });
      toast({ title: `Booking marked as ${status}` });
    } catch (e: any) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    }
  };

  const statusColors: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    accepted: "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-green-700",
    rejected: "bg-red-100 text-red-700",
  };

  return (
    <div className="border border-slate-200 rounded-2xl p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <Badge className={`mb-2 hover:bg-opacity-80 border-none ${statusColors[booking.status] || 'bg-slate-100'}`}>
            {booking.status.toUpperCase()}
          </Badge>
          <h3 className="font-display font-bold text-lg">{booking.service}</h3>
        </div>
        <div className="text-right">
          <Badge variant="outline" className={booking.paymentStatus === 'paid' ? 'border-green-500 text-green-600' : 'border-slate-300'}>
            {booking.paymentStatus === 'paid' ? 'PAID' : 'UNPAID'}
          </Badge>
        </div>
      </div>

      <div className="space-y-2 text-sm text-slate-600 mb-6">
        <div className="flex items-center"><Clock className="w-4 h-4 mr-2" /> {new Date(booking.date).toLocaleString()}</div>
        <div className="flex items-center"><MapPin className="w-4 h-4 mr-2" /> {booking.location}</div>
        <div className="flex items-center">
          <DollarSign className="w-4 h-4 mr-2" /> 
          {userRole === 'technician' ? `Client ID: ${booking.userId}` : `Tech ID: ${booking.technicianId}`}
        </div>
      </div>

      <div className="pt-4 border-t border-slate-100 flex gap-3">
        {userRole === 'technician' && booking.status === 'pending' && (
          <>
            <Button size="sm" onClick={() => handleStatus('accepted')} className="bg-primary text-white flex-1">Accept</Button>
            <Button size="sm" variant="outline" onClick={() => handleStatus('rejected')} className="flex-1">Reject</Button>
          </>
        )}
        
        {userRole === 'technician' && booking.status === 'accepted' && (
          <Button size="sm" onClick={() => handleStatus('completed')} className="bg-accent hover:bg-accent/90 text-white w-full">
            <CheckCircle2 className="w-4 h-4 mr-2" /> Mark Completed
          </Button>
        )}

        {userRole === 'user' && booking.status === 'completed' && booking.paymentStatus === 'pending' && (
          <PaymentModal bookingId={booking.id} />
        )}
      </div>
    </div>
  );
}

function PaymentModal({ bookingId }: { bookingId: number }) {
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const payBooking = usePayBooking();
  const { toast } = useToast();

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await payBooking.mutateAsync({ id: bookingId, phone, amount: Number(amount) });
      toast({ title: "M-Pesa STK Push Sent!", description: "Please check your phone to complete the payment." });
      setIsOpen(false);
    } catch (e: any) {
      toast({ title: "Payment Failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="bg-[#16A34A] hover:bg-[#15803d] text-white w-full shadow-lg shadow-green-500/20">
          Pay with M-Pesa
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl text-center text-[#16A34A]">M-Pesa Payment</DialogTitle>
        </DialogHeader>
        <div className="bg-slate-50 p-4 rounded-xl text-center text-sm text-slate-600 mb-2">
          Enter your M-Pesa registered phone number. An STK push will be sent to your device.
        </div>
        <form onSubmit={handlePay} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1 block">Phone Number</label>
            <Input required placeholder="254700000000" value={phone} onChange={e => setPhone(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Amount (KES)</label>
            <Input required type="number" min="1" placeholder="1500" value={amount} onChange={e => setAmount(e.target.value)} />
          </div>
          <Button type="submit" disabled={payBooking.isPending} className="w-full bg-[#16A34A] hover:bg-[#15803d] text-white h-12 text-lg">
            {payBooking.isPending ? "Sending Request..." : "Send STK Push"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
