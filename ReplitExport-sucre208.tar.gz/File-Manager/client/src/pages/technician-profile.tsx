import { useState } from "react";
import { useParams } from "wouter";
import { Layout } from "@/components/layout";
import { useTechnician } from "@/hooks/use-technicians";
import { useAuth } from "@/hooks/use-auth";
import { useCreateBooking } from "@/hooks/use-bookings";
import { useReviews, useCreateReview } from "@/hooks/use-reviews";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Star, MapPin, Phone, MessageCircle, Clock, ShieldCheck, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TechnicianProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { data: tech, isLoading } = useTechnician(Number(id));
  const { data: reviews } = useReviews(Number(id));
  const { user } = useAuth();
  const createBooking = useCreateBooking();
  const createReview = useCreateReview();
  const { toast } = useToast();

  const [bookingDate, setBookingDate] = useState("");
  const [bookingService, setBookingService] = useState("");
  const [bookingLocation, setBookingLocation] = useState("");
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");

  if (isLoading) return (
    <Layout>
      <div className="container mx-auto py-20 px-4 animate-pulse flex flex-col gap-8">
        <div className="h-64 bg-slate-200 rounded-3xl w-full"></div>
        <div className="h-32 bg-slate-200 rounded-xl w-full max-w-2xl"></div>
      </div>
    </Layout>
  );

  if (!tech) return <Layout><div className="container py-20 text-center">Technician not found</div></Layout>;

  const handleBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({ title: "Authentication required", description: "Please login to book a service.", variant: "destructive" });
      return;
    }
    
    try {
      await createBooking.mutateAsync({
        userId: user.id,
        technicianId: tech.id,
        service: bookingService || tech.services[0],
        date: new Date(bookingDate),
        location: bookingLocation,
      });
      toast({ title: "Booking requested!", description: "The technician will confirm shortly." });
      setIsBookingOpen(false);
    } catch (err: any) {
      toast({ title: "Booking failed", description: err.message, variant: "destructive" });
    }
  };

  const handleReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return toast({ title: "Please login to leave a review", variant: "destructive" });
    
    try {
      await createReview.mutateAsync({
        technicianId: tech.id,
        data: {
          rating: reviewRating,
          comment: reviewComment,
        }
      });
      setReviewComment("");
      toast({ title: "Review submitted!" });
    } catch (err: any) {
      toast({ title: "Failed to submit review", description: err.message, variant: "destructive" });
    }
  };

  return (
    <Layout>
      {/* Profile Header */}
      <div className="bg-primary pb-24 pt-12 text-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-3xl overflow-hidden border-4 border-white/20 shadow-2xl shrink-0 bg-secondary">
              {tech.profileImage ? (
                <img src={tech.profileImage} alt={tech.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-slate-200">
                  <span className="text-4xl text-slate-400 font-bold">{tech.name.charAt(0)}</span>
                </div>
              )}
            </div>
            
            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
                <h1 className="text-3xl md:text-4xl font-display font-bold">{tech.name}</h1>
                {tech.availability && (
                  <Badge className="bg-accent hover:bg-accent border-none text-white mx-auto md:mx-0 w-fit">
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Available Now
                  </Badge>
                )}
              </div>
              
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-white/80 mb-6">
                <div className="flex items-center">
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400 mr-1" />
                  <span className="font-bold text-white text-lg">{Number(tech.rating).toFixed(1)}</span>
                  <span className="ml-1 text-sm">({reviews?.length || 0} reviews)</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-1" /> {tech.location}
                </div>
                <div className="flex items-center">
                  <ShieldCheck className="w-4 h-4 mr-1" /> Verified Pro
                </div>
              </div>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-2">
                {tech.services.map(s => (
                  <span key={s} className="px-3 py-1 bg-white/10 rounded-lg text-sm backdrop-blur-sm border border-white/10">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-5xl -mt-16 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Main Content */}
          <div className="md:col-span-2 space-y-8">
            <div className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
              <h2 className="text-2xl font-display font-bold mb-4">About</h2>
              <p className="text-slate-600 leading-relaxed mb-6">
                Experienced professional offering top-tier services in {tech.services.join(", ")}. 
                With a commitment to quality and customer satisfaction, I ensure every job is done right the first time.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="text-sm text-slate-500 mb-1">Service Radius</div>
                  <div className="font-semibold text-foreground flex items-center">
                    <MapPin className="w-4 h-4 mr-2 text-primary" /> {tech.serviceRadius} km
                  </div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="text-sm text-slate-500 mb-1">Price Range</div>
                  <div className="font-semibold text-foreground flex items-center">
                    <Clock className="w-4 h-4 mr-2 text-primary" /> {tech.priceRange || 'Contact for quote'}
                  </div>
                </div>
              </div>
            </div>

            {/* Reviews Section */}
            <div className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
              <h2 className="text-2xl font-display font-bold mb-6">Reviews</h2>
              
              {user && user.role === 'user' && (
                <form onSubmit={handleReview} className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                  <h4 className="font-semibold mb-3">Leave a Review</h4>
                  <div className="flex items-center gap-2 mb-4">
                    {[1,2,3,4,5].map(star => (
                      <Star 
                        key={star} 
                        className={`w-6 h-6 cursor-pointer transition-colors ${star <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-slate-300'}`}
                        onClick={() => setReviewRating(star)}
                      />
                    ))}
                  </div>
                  <Textarea 
                    value={reviewComment}
                    onChange={e => setReviewComment(e.target.value)}
                    placeholder="Share your experience..." 
                    className="mb-4 bg-white"
                  />
                  <Button type="submit" disabled={createReview.isPending}>
                    {createReview.isPending ? "Submitting..." : "Post Review"}
                  </Button>
                </form>
              )}

              <div className="space-y-6">
                {reviews?.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No reviews yet.</p>
                ) : (
                  reviews?.map(review => (
                    <div key={review.id} className="border-b last:border-0 pb-6 last:pb-0">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-semibold text-foreground">User #{review.userId}</div>
                        <div className="text-sm text-slate-500">{new Date(review.date!).toLocaleDateString()}</div>
                      </div>
                      <div className="flex items-center mb-2">
                        {[1,2,3,4,5].map(star => (
                          <Star key={star} className={`w-4 h-4 ${star <= review.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200'}`} />
                        ))}
                      </div>
                      <p className="text-slate-600 text-sm">{review.comment}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-xl shadow-slate-200/50 border border-slate-100 sticky top-24">
              <h3 className="text-xl font-display font-bold mb-6">Ready to hire?</h3>
              
              <Dialog open={isBookingOpen} onOpenChange={setIsBookingOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" className="w-full h-14 text-lg rounded-2xl bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20 mb-4">
                    Book Service Now
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle className="font-display text-2xl">Book {tech.name}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleBook} className="space-y-4 mt-4">
                    <div>
                      <label className="text-sm font-medium mb-1 block">Service Needed</label>
                      <select 
                        required
                        value={bookingService}
                        onChange={e => setBookingService(e.target.value)}
                        className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                      >
                        <option value="">Select a service</option>
                        {tech.services.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">Preferred Date & Time</label>
                      <Input 
                        type="datetime-local" 
                        required 
                        value={bookingDate}
                        onChange={e => setBookingDate(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">Your Location / Address</label>
                      <Textarea 
                        required 
                        placeholder="House number, Street, Landmark..."
                        value={bookingLocation}
                        onChange={e => setBookingLocation(e.target.value)}
                      />
                    </div>
                    <Button type="submit" className="w-full mt-4 h-12 text-lg" disabled={createBooking.isPending}>
                      {createBooking.isPending ? "Sending Request..." : "Confirm Booking Request"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>

              <div className="flex items-center justify-center my-4 text-slate-400 text-sm font-medium">OR</div>

              <a 
                href={`https://wa.me/${tech.whatsapp.replace(/[^0-9]/g, '')}`} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center justify-center w-full h-14 rounded-2xl bg-[#25D366] text-white font-bold hover:bg-[#20bd5a] transition-colors shadow-lg shadow-[#25D366]/20"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Chat on WhatsApp
              </a>

              <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col gap-4">
                <div className="flex items-center text-slate-600">
                  <Phone className="w-5 h-5 mr-3 text-primary" />
                  <span className="font-medium">{tech.phone}</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
}
