import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useTechnicians } from "@/hooks/use-technicians";
import { TechnicianCard } from "@/components/technician-card";
import { Search, MapPin, Filter, X } from "lucide-react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";

// Fix leaflet icon issue in React
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

export default function SearchPage() {
  const [location] = useLocation();
  const queryParams = new URLSearchParams(window.location.search);
  
  const [search, setSearch] = useState(queryParams.get("q") || "");
  const [category, setCategory] = useState(queryParams.get("category") || "");
  
  const { data: technicians, isLoading } = useTechnicians(search, category);

  // Nairobi Default Center
  const center: [number, number] = [-1.2921, 36.8219];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Re-trigger query via state, React Query handles the refetch based on queryKey
  };

  const clearFilters = () => {
    setSearch("");
    setCategory("");
  };

  return (
    <Layout>
      <div className="flex-1 flex flex-col md:flex-row h-[calc(100vh-64px)]">
        {/* Left Panel: Search & List */}
        <div className="w-full md:w-[500px] lg:w-[600px] flex flex-col border-r bg-slate-50 overflow-hidden shrink-0">
          <div className="p-4 border-b bg-white">
            <h1 className="text-2xl font-display font-bold mb-4">Find Technicians</h1>
            <form onSubmit={handleSearch} className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by name, location, service..." 
                  className="pl-9 bg-slate-50"
                />
              </div>
              <div className="flex gap-2">
                <select 
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-slate-50 px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="">All Categories</option>
                  <option value="Plumbing">Plumbing</option>
                  <option value="Electrical">Electrical</option>
                  <option value="Carpentry">Carpentry</option>
                  <option value="Cleaning">Cleaning</option>
                </select>
                {(search || category) && (
                  <Button type="button" variant="outline" onClick={clearFilters} size="icon" className="shrink-0">
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </form>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {isLoading ? (
              Array(4).fill(0).map((_, i) => (
                <div key={i} className="bg-white rounded-xl h-40 animate-pulse border border-border" />
              ))
            ) : technicians?.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground py-20 text-center px-4">
                <Filter className="w-12 h-12 mb-4 text-slate-300" />
                <h3 className="text-lg font-display font-semibold text-foreground">No technicians found</h3>
                <p className="text-sm mt-1">Try adjusting your filters or searching a different area.</p>
                <Button variant="outline" className="mt-4" onClick={clearFilters}>Clear Filters</Button>
              </div>
            ) : (
              technicians?.map(tech => (
                <TechnicianCard key={tech.id} technician={tech} />
              ))
            )}
          </div>
        </div>

        {/* Right Panel: Map */}
        <div className="hidden md:block flex-1 relative bg-slate-200">
          <MapContainer 
            center={center} 
            zoom={12} 
            scrollWheelZoom={true} 
            className="w-full h-full absolute inset-0 z-0"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
            />
            {technicians?.map((tech) => {
              if (!tech.latitude || !tech.longitude) return null;
              return (
                <Marker key={tech.id} position={[Number(tech.latitude), Number(tech.longitude)]}>
                  <Popup className="rounded-xl overflow-hidden shadow-xl border-0">
                    <div className="p-1 min-w-[200px]">
                      <h4 className="font-bold font-display text-base">{tech.name}</h4>
                      <p className="text-sm text-muted-foreground">{tech.services[0]}</p>
                      <Button size="sm" className="w-full mt-2" onClick={() => window.location.href = `/technician/${tech.id}`}>
                        View Profile
                      </Button>
                    </div>
                  </Popup>
                </Marker>
              );
            })}
          </MapContainer>
        </div>
      </div>
    </Layout>
  );
}
