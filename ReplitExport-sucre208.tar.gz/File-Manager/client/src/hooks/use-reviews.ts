import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

type CreateReviewInput = z.infer<typeof api.reviews.create.input>;

export function useReviews(technicianId: number) {
  return useQuery({
    queryKey: [api.reviews.list.path, technicianId],
    queryFn: async () => {
      const url = buildUrl(api.reviews.list.path, { id: technicianId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch reviews");
      return api.reviews.list.responses[200].parse(await res.json());
    },
    enabled: !!technicianId,
  });
}

export function useCreateReview() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ technicianId, data }: { technicianId: number, data: CreateReviewInput }) => {
      const url = buildUrl(api.reviews.create.path, { id: technicianId });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to post review");
      return api.reviews.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.reviews.list.path, variables.technicianId] });
      queryClient.invalidateQueries({ queryKey: [api.technicians.get.path, variables.technicianId] });
    },
  });
}
