import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

type Technician = z.infer<typeof api.technicians.get.responses[200]>;
type CreateTechnicianInput = z.infer<typeof api.technicians.create.input>;
type UpdateTechnicianInput = z.infer<typeof api.technicians.update.input>;

export function useTechnicians(search?: string, category?: string) {
  return useQuery({
    queryKey: [api.technicians.list.path, search, category],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.append("search", search);
      if (category) params.append("category", category);
      
      const url = `${api.technicians.list.path}?${params.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch technicians");
      return api.technicians.list.responses[200].parse(await res.json());
    },
  });
}

export function useTechnician(id: number) {
  return useQuery({
    queryKey: [api.technicians.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.technicians.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch technician");
      return api.technicians.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateTechnician() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateTechnicianInput) => {
      const res = await fetch(api.technicians.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create technician profile");
      return api.technicians.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.technicians.list.path] }),
  });
}

export function useUpdateTechnician() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & UpdateTechnicianInput) => {
      const url = buildUrl(api.technicians.update.path, { id });
      const res = await fetch(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update technician profile");
      return api.technicians.update.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.technicians.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.technicians.get.path, variables.id] });
    },
  });
}
