## Packages
leaflet | Required for map visualization
react-leaflet | React components for Leaflet maps
@types/leaflet | TypeScript definitions for Leaflet
framer-motion | Animations and page transitions
lucide-react | Icons

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
