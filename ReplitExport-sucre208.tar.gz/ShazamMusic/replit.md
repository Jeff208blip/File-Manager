# Shazad Enterprise - E-commerce Platform

## Overview

This is a full-stack e-commerce web application for Shazad Enterprise, a Kenyan construction materials supplier. The application allows customers to browse products, request quotes, and contact the business. It features a modern React frontend with a Node.js/Express backend, using PostgreSQL for data persistence.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite for build tooling
- **Backend**: Node.js with Express.js REST API
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state, custom hooks for local state
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **React SPA** built with TypeScript and Vite
- **Component Library**: shadcn/ui components for consistent design
- **Styling**: Tailwind CSS with custom brand colors and design system
- **State Management**: 
  - TanStack Query for API data fetching and caching
  - Custom cart hook for shopping cart functionality
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Express.js REST API** with TypeScript
- **Storage Layer**: Abstracted storage interface with in-memory implementation (ready for database integration)
- **Route Handlers**: Separate route definitions for clean API structure
- **Middleware**: Request logging, JSON parsing, error handling

### Database Schema
Using Drizzle ORM with PostgreSQL, the schema includes:
- **Users**: Authentication and user management
- **Products**: Construction materials catalog
- **Quote Requests**: Customer quote inquiries with cart items
- **Contact Inquiries**: General customer contact messages

### UI/UX Design
- **Brand Identity**: Navy blue, green, and red color scheme representing professionalism and trust
- **Responsive Design**: Mobile-first approach with breakpoint optimization
- **Component System**: Comprehensive shadcn/ui component library
- **Cart Functionality**: Side-panel cart with quote request system

## Data Flow

1. **Product Browsing**: Customers view products fetched from the REST API
2. **Cart Management**: Items are added to a local cart state managed by React hooks
3. **Quote Requests**: Cart contents are submitted as quote requests to the backend
4. **Contact Inquiries**: Contact form submissions are processed through the API
5. **Data Persistence**: All business data is stored in PostgreSQL via Drizzle ORM

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, React Query
- **UI Components**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **Forms**: React Hook Form with Zod validation
- **Date Handling**: date-fns for date manipulation

### Backend Dependencies
- **Server**: Express.js with TypeScript support
- **Database**: Drizzle ORM with PostgreSQL adapter (@neondatabase/serverless)
- **Validation**: Zod for schema validation
- **Session Management**: connect-pg-simple for PostgreSQL session storage

### Development Dependencies
- **Build Tools**: Vite for frontend bundling, ESBuild for backend bundling
- **TypeScript**: Full TypeScript support across the stack
- **Development**: tsx for TypeScript execution in development

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

### Build Process
- **Frontend Build**: Vite builds the React application to `dist/public`
- **Backend Build**: ESBuild bundles the server code to `dist/index.js`
- **Database**: PostgreSQL 16 module configured in Replit environment

### Environment Configuration
- **Development**: `npm run dev` runs the TypeScript server with hot reloading
- **Production**: `npm run build && npm run start` for optimized deployment
- **Database**: Environment variable `DATABASE_URL` required for PostgreSQL connection

### Deployment Settings
- **Port Configuration**: Server runs on port 5000, exposed as port 80
- **Static Assets**: Frontend assets served from `/dist/public`
- **API Routes**: Backend API available at `/api/*` endpoints

## Changelog

```
Changelog:
- June 20, 2025. Initial setup
- June 20, 2025. Updated company name from "Shazad Construction Materials" to "Shazad Enterprise"
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```