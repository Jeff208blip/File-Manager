import React from "react";

const products = [
  {
    name: "Cement (50kg)",
    price: "KES 750",
    image: "https://images.unsplash.com/photo-1608506381361-0666f147f9c1",
  },
  {
    name: "Steel Rebars",
    price: "KES 1000/pc",
    image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be",
  },
  {
    name: "Concrete Blocks",
    price: "KES 50",
    image: "https://images.unsplash.com/photo-1581092027981-553db202fe6b",
  },
];

export default function App() {
  return (
    <div style={{ fontFamily: "Arial, sans-serif", backgroundColor: "#f4f4f4" }}>
      <header style={{ backgroundColor: "#003366", color: "white", padding: "1em 0", textAlign: "center" }}>
        <h1>Shazad Construction Materials</h1>
        <p>Build Smart. Build Strong.</p>
      </header>

      <nav style={{ background: "#0055a5", display: "flex", justifyContent: "center", padding: "0.5em 0" }}>
        {['Home', 'Products', 'Contact', 'About Us'].map((link) => (
          <a
            key={link}
            href={`#${link.toLowerCase().replace(/\s+/g, '')}`}
            style={{ color: "white", margin: "0 1em", textDecoration: "none" }}
          >
            {link}
          </a>
        ))}
      </nav>

      <div
        style={{
          background: `url('https://images.unsplash.com/photo-1581091012184-d58d5c4cd4a7') no-repeat center center/cover`,
          height: "300px",
          color: "white",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          textShadow: "2px 2px 5px black",
        }}
      >
        <h1>Your Trusted Building Materials Supplier</h1>
      </div>

      <div style={{ padding: "2em" }} id="products">
        <h2>Our Products</h2>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "1.5em",
          }}
        >
          {products.map((product, index) => (
            <div
              key={index}
              style={{
                background: "white",
                padding: "1em",
                borderRadius: "8px",
                boxShadow: "0 0 5px rgba(0,0,0,0.1)",
                textAlign: "center",
              }}
            >
              <img
                src={product.image}
                alt={product.name}
                style={{ width: "100%", height: "150px", objectFit: "cover", borderRadius: "4px" }}
              />
              <h3 style={{ margin: "0.5em 0" }}>{product.name}</h3>
              <p>{product.price}</p>
              <button
                style={{
                  background: "#003366",
                  color: "white",
                  border: "none",
                  padding: "0.5em 1em",
                  borderRadius: "4px",
                  cursor: "pointer",
                }}
              >
                Add to Quote
              </button>
            </div>
          ))}
        </div>
      </div>

      <footer style={{ background: "#222", color: "white", textAlign: "center", padding: "1em" }}>
        <p>&copy; 2025 Shazad Construction Materials. All rights reserved.</p>
        <p>Email: info@shazadmaterials.co.ke | Phone: +254 712 345678</p>
      </footer>
    </div>
  );
}
