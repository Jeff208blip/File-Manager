import { 
  users, 
  products, 
  quoteRequests, 
  contactInquiries,
  type User, 
  type InsertUser,
  type Product,
  type InsertProduct,
  type QuoteRequest,
  type InsertQuoteRequest,
  type ContactInquiry,
  type InsertContactInquiry
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  createQuoteRequest(quote: InsertQuoteRequest): Promise<QuoteRequest>;
  getAllQuoteRequests(): Promise<QuoteRequest[]>;
  getQuoteRequest(id: number): Promise<QuoteRequest | undefined>;
  
  createContactInquiry(inquiry: InsertContactInquiry): Promise<ContactInquiry>;
  getAllContactInquiries(): Promise<ContactInquiry[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.category, category));
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(insertProduct)
      .returning();
    return product;
  }

  async createQuoteRequest(insertQuote: InsertQuoteRequest): Promise<QuoteRequest> {
    const [quote] = await db
      .insert(quoteRequests)
      .values({
        ...insertQuote,
        customerPhone: insertQuote.customerPhone || null,
        status: insertQuote.status || "pending"
      })
      .returning();
    return quote;
  }

  async getAllQuoteRequests(): Promise<QuoteRequest[]> {
    return await db.select().from(quoteRequests);
  }

  async getQuoteRequest(id: number): Promise<QuoteRequest | undefined> {
    const [quote] = await db.select().from(quoteRequests).where(eq(quoteRequests.id, id));
    return quote || undefined;
  }

  async createContactInquiry(insertInquiry: InsertContactInquiry): Promise<ContactInquiry> {
    const [inquiry] = await db
      .insert(contactInquiries)
      .values({
        ...insertInquiry,
        phone: insertInquiry.phone || null
      })
      .returning();
    return inquiry;
  }

  async getAllContactInquiries(): Promise<ContactInquiry[]> {
    return await db.select().from(contactInquiries);
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private quoteRequests: Map<number, QuoteRequest>;
  private contactInquiries: Map<number, ContactInquiry>;
  private currentUserId: number;
  private currentProductId: number;
  private currentQuoteId: number;
  private currentInquiryId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.quoteRequests = new Map();
    this.contactInquiries = new Map();
    this.currentUserId = 1;
    this.currentProductId = 1;
    this.currentQuoteId = 1;
    this.currentInquiryId = 1;
    
    // Initialize with sample products
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: Omit<Product, 'id'>[] = [
      {
        name: "Premium Cement (50kg)",
        description: "High-grade Portland cement, 50kg bags",
        price: 75000, // KES 750 in cents
        category: "cement",
        image: "https://images.unsplash.com/photo-1608506381361-0666f147f9c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Steel Rebars",
        description: "High tensile strength reinforcement bars",
        price: 100000, // KES 1000 in cents
        category: "steel",
        image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Concrete Blocks",
        description: "Standard 6-inch concrete masonry units",
        price: 5000, // KES 50 in cents
        category: "blocks",
        image: "https://images.unsplash.com/photo-1581092027981-553db202fe6b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Construction Sand (Ton)",
        description: "Fine grade construction sand",
        price: 250000, // KES 2500 in cents
        category: "cement",
        image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Ballast (Ton)",
        description: "Machine crushed ballast",
        price: 300000, // KES 3000 in cents
        category: "cement",
        image: "https://images.unsplash.com/photo-1587573089548-47e61ac8bb0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Iron Sheets (Gauge 30)",
        description: "Galvanized iron roofing sheets",
        price: 85000, // KES 850 in cents
        category: "roofing",
        image: "https://images.unsplash.com/photo-1558618666-9c4b0c4dbfc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Roof Tiles",
        description: "Clay roof tiles",
        price: 6500, // KES 65 in cents
        category: "roofing",
        image: "https://images.unsplash.com/photo-1604079628040-94301bb21b91?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Wire Mesh (Roll)",
        description: "Welded wire mesh for construction",
        price: 150000, // KES 1500 in cents
        category: "steel",
        image: "https://images.unsplash.com/photo-1572363818807-50eb81727134?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      },
      {
        name: "Assorted Nails (Kg)",
        description: "Various sizes of construction nails",
        price: 12000, // KES 120 in cents
        category: "tools",
        image: "https://images.unsplash.com/photo-1585435557343-3b092031c4fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        inStock: true
      }
    ];

    sampleProducts.forEach(product => {
      const id = this.currentProductId++;
      this.products.set(id, { ...product, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      product => product.category === category
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { ...insertProduct, id };
    this.products.set(id, product);
    return product;
  }

  async createQuoteRequest(insertQuote: InsertQuoteRequest): Promise<QuoteRequest> {
    const id = this.currentQuoteId++;
    const quote: QuoteRequest = { 
      ...insertQuote, 
      id,
      createdAt: new Date()
    };
    this.quoteRequests.set(id, quote);
    return quote;
  }

  async getAllQuoteRequests(): Promise<QuoteRequest[]> {
    return Array.from(this.quoteRequests.values());
  }

  async getQuoteRequest(id: number): Promise<QuoteRequest | undefined> {
    return this.quoteRequests.get(id);
  }

  async createContactInquiry(insertInquiry: InsertContactInquiry): Promise<ContactInquiry> {
    const id = this.currentInquiryId++;
    const inquiry: ContactInquiry = { 
      ...insertInquiry, 
      id,
      createdAt: new Date()
    };
    this.contactInquiries.set(id, inquiry);
    return inquiry;
  }

  async getAllContactInquiries(): Promise<ContactInquiry[]> {
    return Array.from(this.contactInquiries.values());
  }
}

export const storage = new DatabaseStorage();
