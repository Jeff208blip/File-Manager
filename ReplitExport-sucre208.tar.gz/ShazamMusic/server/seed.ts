import { db } from "./db";
import { products } from "@shared/schema";

const sampleProducts = [
  {
    name: "Premium Cement (50kg)",
    description: "High-grade Portland cement, 50kg bags",
    price: 75000, // KES 750 in cents
    category: "cement",
    image: "https://images.unsplash.com/photo-1608506381361-0666f147f9c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Steel Rebars",
    description: "High tensile strength reinforcement bars",
    price: 100000, // KES 1000 in cents
    category: "steel",
    image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Concrete Blocks",
    description: "Standard 6-inch concrete masonry units",
    price: 5000, // KES 50 in cents
    category: "blocks",
    image: "https://images.unsplash.com/photo-1581092027981-553db202fe6b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Construction Sand (Ton)",
    description: "Fine grade construction sand",
    price: 250000, // KES 2500 in cents
    category: "cement",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Ballast (Ton)",
    description: "Machine crushed ballast",
    price: 300000, // KES 3000 in cents
    category: "cement",
    image: "https://images.unsplash.com/photo-1587573089548-47e61ac8bb0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Iron Sheets (Gauge 30)",
    description: "Galvanized iron roofing sheets",
    price: 85000, // KES 850 in cents
    category: "roofing",
    image: "https://images.unsplash.com/photo-1558618666-9c4b0c4dbfc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Roof Tiles",
    description: "Clay roof tiles",
    price: 6500, // KES 65 in cents
    category: "roofing",
    image: "https://images.unsplash.com/photo-1604079628040-94301bb21b91?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Wire Mesh (Roll)",
    description: "Welded wire mesh for construction",
    price: 150000, // KES 1500 in cents
    category: "steel",
    image: "https://images.unsplash.com/photo-1572363818807-50eb81727134?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  },
  {
    name: "Assorted Nails (Kg)",
    description: "Various sizes of construction nails",
    price: 12000, // KES 120 in cents
    category: "tools",
    image: "https://images.unsplash.com/photo-1585435557343-3b092031c4fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    inStock: true
  }
];

async function seedDatabase() {
  try {
    console.log("Seeding database with sample products...");
    
    // Check if products already exist
    const existingProducts = await db.select().from(products);
    if (existingProducts.length > 0) {
      console.log("Database already has products, skipping seed.");
      return;
    }
    
    // Insert sample products
    await db.insert(products).values(sampleProducts);
    console.log(`Seeded ${sampleProducts.length} products successfully!`);
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Run seed if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase().then(() => process.exit(0));
}

export { seedDatabase };