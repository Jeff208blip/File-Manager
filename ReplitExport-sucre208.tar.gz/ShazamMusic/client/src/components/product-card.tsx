import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { formatPrice } from "@/lib/cart";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow">
      <div className="aspect-video overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4 text-sm">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-xl font-bold text-brand-navy">
            {formatPrice(product.price)}
          </span>
          <Button
            onClick={() => onAddToCart(product)}
            className="bg-brand-blue hover:bg-brand-navy"
          >
            <ShoppingCart className="h-4 w-4 mr-1" />
            Add to Quote
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
