import { Link } from "wouter";
import { HardHat, MapPin, Phone, Mail, Clock, Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <HardHat className="h-8 w-8 text-yellow-400" />
              <div>
                <h3 className="text-lg font-bold">Shazad Enterprise</h3>
                <p className="text-sm text-gray-400">Build Smart. Build Strong.</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Kenya's trusted enterprise supplier since 2008. Quality materials, competitive prices, reliable delivery.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
              <li><Link href="/products" className="text-gray-400 hover:text-white transition-colors">All Products</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Delivery Info</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Returns Policy</a></li>
            </ul>
          </div>

          {/* Product Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Product Categories</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cement & Aggregates</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Steel & Metal</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Blocks & Bricks</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Roofing Materials</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Tools & Hardware</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Plumbing Supplies</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-3">
                <MapPin className="h-4 w-4 text-brand-blue mt-1 flex-shrink-0" />
                <span className="text-gray-400">Industrial Area, Nairobi<br />P.O. Box 12345-00100</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-brand-green flex-shrink-0" />
                <span className="text-gray-400">+254 712 345 678</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-yellow-500 flex-shrink-0" />
                <span className="text-gray-400">info@shazadmaterials.co.ke</span>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="h-4 w-4 text-purple-500 mt-1 flex-shrink-0" />
                <span className="text-gray-400">Mon-Fri: 7AM-6PM<br />Sat: 8AM-4PM</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
            <p>&copy; 2025 Shazad Enterprise. All rights reserved.</p>
            <div className="flex space-x-6 mt-2 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Sitemap</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
