import { Card, CardContent } from "@/components/ui/card";
import { Target, Eye, Heart } from "lucide-react";

export default function About() {
  return (
    <div className="py-12 bg-white min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">About Shazad Enterprise</h2>
            <p className="text-lg text-gray-600">Building Kenya's future with quality materials since 2008</p>
          </div>

          {/* Company Story */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">Our Story</h3>
              <p className="text-gray-600 mb-4">
                Founded in 2008 by Mohammed Shazad, Shazad Enterprise began as a small family business with a simple vision: to provide high-quality construction materials at fair prices to contractors across Kenya.
              </p>
              <p className="text-gray-600 mb-4">
                Over the years, we've grown from a single warehouse in Industrial Area to become one of Kenya's most trusted enterprise suppliers, serving thousands of contractors, builders, and homeowners.
              </p>
              <p className="text-gray-600">
                Today, we continue to uphold our founding principles of quality, reliability, and customer service, while embracing modern technology to serve our customers better.
              </p>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Construction warehouse" 
                className="rounded-xl shadow-lg w-full"
              />
            </div>
          </div>

          {/* Mission, Vision, Values */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-brand-blue text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Our Mission</h3>
                <p className="text-gray-600">To provide high-quality construction materials and exceptional service that empowers builders to create lasting structures across Kenya.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-brand-green text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Eye className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Our Vision</h3>
                <p className="text-gray-600">To be East Africa's leading construction materials supplier, known for innovation, sustainability, and unwavering commitment to quality.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-yellow-500 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Our Values</h3>
                <p className="text-gray-600">Integrity, quality, customer service, innovation, and community responsibility guide everything we do.</p>
              </CardContent>
            </Card>
          </div>

          {/* Team Section */}
          <div className="mb-16">
            <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">Our Leadership Team</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
                  alt="Mohammed Shazad" 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h4 className="text-lg font-semibold text-gray-900">Mohammed Shazad</h4>
                <p className="text-brand-blue font-medium">Founder & CEO</p>
                <p className="text-sm text-gray-600 mt-2">15+ years in construction materials industry</p>
              </div>

              <div className="text-center">
                <img 
                  src="https://images.unsplash.com/photo-1494790108755-2616b612b372?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
                  alt="Sarah Kimani" 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h4 className="text-lg font-semibold text-gray-900">Sarah Kimani</h4>
                <p className="text-brand-blue font-medium">Operations Manager</p>
                <p className="text-sm text-gray-600 mt-2">Expert in logistics and supply chain management</p>
              </div>

              <div className="text-center">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
                  alt="David Ochieng" 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h4 className="text-lg font-semibold text-gray-900">David Ochieng</h4>
                <p className="text-brand-blue font-medium">Sales Director</p>
                <p className="text-sm text-gray-600 mt-2">Building relationships with contractors nationwide</p>
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div className="bg-brand-navy text-white rounded-xl p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-yellow-400 mb-2">15+</div>
                <div className="text-blue-200">Years in Business</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-yellow-400 mb-2">5000+</div>
                <div className="text-blue-200">Happy Customers</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-yellow-400 mb-2">500+</div>
                <div className="text-blue-200">Products Available</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-yellow-400 mb-2">47</div>
                <div className="text-blue-200">Counties Served</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
