import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  User, 
  Calendar, 
  Flag, 
  Languages, 
  Briefcase, 
  GraduationCap, 
  Cog, 
  Award, 
  Mail, 
  Phone,
  MessageCircle,
  Users,
  Brain,
  Lightbulb,
  Laptop,
  HandHeart,
  Drama,
  Map
} from "lucide-react";

const personalInfo = [
  { label: "Full Name", value: "Karanja Jeff Kamau", icon: User },
  { label: "Date of Birth", value: "1st July, 2001", icon: Calendar },
  { label: "Nationality", value: "Kenyan", icon: Flag },
  { label: "Languages", value: "English, Kiswahili", icon: Languages },
];

const workExperience = [
  {
    company: "Mayaash",
    position: "Safaricom Field Agent",
    duration: "July 2024 – Mar 2025",
    description: "Field operations and customer service excellence in telecommunications sector."
  },
  {
    company: "Call Center International",
    position: "Call Agent",
    duration: "Aug 2023 – June 2024",
    description: "Customer support and service delivery with focus on problem resolution."
  },
  {
    company: "Seven Sundays",
    position: "Sales Agent",
    duration: "Feb 2023 – May 2023",
    description: "Sales and customer relationship management with achievement of targets."
  },
  {
    company: "Autocom Computers",
    position: "Sales Agent",
    duration: "Jan 2022 – Sept 2022",
    description: "Technology sales and customer consultation in computer hardware and software."
  }
];

const education = [
  {
    degree: "BSc in Software Development",
    institution: "University",
    duration: "2012–2025"
  },
  {
    degree: "KCSE",
    institution: "Othaya Boys High School",
    duration: "2016–2019"
  },
  {
    degree: "KCPE",
    institution: "Josnem Academy",
    duration: "2008–2015"
  }
];

const skills = [
  { name: "Communication & Listening", icon: MessageCircle },
  { name: "Teamwork & Collaboration", icon: Users },
  { name: "Analytical Thinking", icon: Brain },
  { name: "Problem Solving & Decision Making", icon: Lightbulb },
  { name: "MS Office Tools", icon: Laptop },
];

const certifications = [
  {
    name: "Computer Literacy",
    issuer: "KCA University & Essy Cyber",
    icon: Award
  },
  {
    name: "Peer Counselor",
    issuer: "Othaya Boys High School",
    icon: HandHeart
  },
  {
    name: "National Drama Festivals",
    issuer: "Ministry of Education",
    icon: Drama
  },
  {
    name: "Afya Yetu Survey",
    issuer: "2021",
    icon: Award
  },
  {
    name: "SamaSource LiDAR Training",
    issuer: "2022",
    icon: Map
  }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-light-bg">
      {/* Header */}
      <header className="bg-primary-dark text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-dark to-gray-900"></div>
        <div className="relative max-w-6xl mx-auto px-4 py-16 lg:py-24">
          <div className="text-center">
            {/* Profile Image Placeholder */}
            <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-accent-blue to-blue-600 flex items-center justify-center text-4xl font-bold">
              KJ
            </div>
            
            <h1 className="text-4xl lg:text-5xl font-bold mb-4">
              Karanja Developer
            </h1>
            <p className="text-xl lg:text-2xl text-gray-300 mb-6">
              Software Developer | Tech Enthusiast | Problem Solver
            </p>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-8">
              Passionate and detail-oriented developer with excellent interpersonal skills. 
              I'm reliable, enthusiastic, and eager to grow through knowledge and experience.
            </p>
            
            {/* Contact CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild className="bg-accent-blue hover:bg-blue-700 text-white px-6 py-3">
                <a href="mailto:karanjajefferson7@gmail.com">
                  <Mail className="mr-2 h-4 w-4" />
                  Get In Touch
                </a>
              </Button>
              <Button variant="outline" asChild className="border-2 border-white text-white hover:bg-white hover:text-primary-dark px-6 py-3">
                <a href="tel:+254799153149">
                  <Phone className="mr-2 h-4 w-4" />
                  Call Me
                </a>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-12">
        
        {/* Personal Information Section */}
        <section className="mb-16">
          <Card className="p-8 border-l-4 border-accent-blue">
            <h2 className="text-3xl font-bold mb-6 text-secondary-dark flex items-center">
              <User className="text-accent-blue mr-3 h-8 w-8" />
              Personal Information
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {personalInfo.map((info, index) => {
                const IconComponent = info.icon;
                return (
                  <div key={index} className="flex items-center p-4 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 bg-accent-blue rounded-full flex items-center justify-center text-white mr-4">
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{info.label}</p>
                      <p className="text-gray-600">{info.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </section>

        {/* Work Experience Section */}
        <section className="mb-16">
          <Card className="p-8">
            <h2 className="text-3xl font-bold mb-8 text-secondary-dark flex items-center">
              <Briefcase className="text-accent-blue mr-3 h-8 w-8" />
              Work Experience
            </h2>
            
            <div className="space-y-6">
              {workExperience.map((job, index) => (
                <div key={index} className="relative pl-8 border-l-2 border-gray-200 last:border-l-0">
                  <div className="absolute -left-3 top-0 w-6 h-6 bg-accent-blue rounded-full border-4 border-white"></div>
                  <div className="bg-gray-50 rounded-lg p-6 ml-4">
                    <h3 className="text-xl font-semibold text-secondary-dark">{job.company}</h3>
                    <p className="text-accent-blue font-medium mb-2">{job.position}</p>
                    <p className="text-gray-600 text-sm mb-3">{job.duration}</p>
                    <p className="text-gray-700">{job.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </section>

        {/* Education & Skills Grid */}
        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          
          {/* Education Section */}
          <Card className="p-8">
            <h2 className="text-3xl font-bold mb-6 text-secondary-dark flex items-center">
              <GraduationCap className="text-accent-blue mr-3 h-8 w-8" />
              Education
            </h2>
            
            <div className="space-y-6">
              {education.map((edu, index) => (
                <div key={index} className={`border-l-4 pl-6 ${index === 0 ? 'border-accent-blue' : 'border-gray-300'}`}>
                  <h3 className="text-lg font-semibold text-secondary-dark">{edu.degree}</h3>
                  <p className={`font-medium ${index === 0 ? 'text-accent-blue' : 'text-gray-700'}`}>{edu.institution}</p>
                  <p className="text-gray-600 text-sm">{edu.duration}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* Skills Section */}
          <Card className="p-8">
            <h2 className="text-3xl font-bold mb-6 text-secondary-dark flex items-center">
              <Cog className="text-accent-blue mr-3 h-8 w-8" />
              Skills
            </h2>
            
            <div className="space-y-4">
              {skills.map((skill, index) => {
                const IconComponent = skill.icon;
                return (
                  <div key={index} className="flex items-center p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100 hover:border-accent-blue transition-colors duration-200">
                    <div className="w-10 h-10 bg-accent-blue rounded-full flex items-center justify-center text-white mr-4">
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <span className="font-medium text-secondary-dark">{skill.name}</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Certifications Section */}
        <section className="mb-16">
          <Card className="p-8">
            <h2 className="text-3xl font-bold mb-6 text-secondary-dark flex items-center">
              <Award className="text-accent-blue mr-3 h-8 w-8" />
              Certifications & Activities
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              {certifications.map((cert, index) => {
                const IconComponent = cert.icon;
                return (
                  <div key={index} className="flex items-start p-6 bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg border hover:shadow-md transition-shadow duration-200">
                    <div className="w-12 h-12 bg-gradient-to-br from-accent-blue to-blue-600 rounded-full flex items-center justify-center text-white mr-4 flex-shrink-0">
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-secondary-dark mb-1">{cert.name}</h3>
                      <p className="text-gray-600 text-sm">{cert.issuer}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </section>

        {/* Contact Section */}
        <section className="mb-16">
          <div className="bg-gradient-to-br from-accent-blue to-blue-600 rounded-xl shadow-lg p-8 text-white">
            <h2 className="text-3xl font-bold mb-6 flex items-center">
              <Mail className="text-white mr-3 h-8 w-8" />
              Let's Connect
            </h2>
            <p className="text-blue-100 mb-8 text-lg">Ready to collaborate or have questions? I'd love to hear from you!</p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <a 
                href="mailto:karanjajefferson7@gmail.com" 
                className="flex items-center p-6 bg-white bg-opacity-10 rounded-lg hover:bg-opacity-20 transition-all duration-200 group"
              >
                <div className="w-14 h-14 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4 group-hover:bg-opacity-30 transition-all duration-200">
                  <Mail className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Email Me</p>
                  <p className="text-blue-100">karanjajefferson7@gmail.com</p>
                </div>
              </a>
              
              <a 
                href="tel:+254799153149" 
                className="flex items-center p-6 bg-white bg-opacity-10 rounded-lg hover:bg-opacity-20 transition-all duration-200 group"
              >
                <div className="w-14 h-14 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4 group-hover:bg-opacity-30 transition-all duration-200">
                  <Phone className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Call Me</p>
                  <p className="text-blue-100">+254 799 153149</p>
                </div>
              </a>
            </div>
          </div>
        </section>
        
      </main>

      {/* Footer */}
      <footer className="bg-primary-dark text-white">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">
            <p className="text-gray-400 mb-4">
              &copy; 2025 Karanja Developer. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm">
              Built with passion for clean code and great user experiences.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
