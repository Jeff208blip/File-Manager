// index.js
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);


// App.js
import React from "react";
import "./App.css";

export default function App() {
  return (
    <div className="App">
      <header className="header">
        <h1>Karanja Developer</h1>
        <p>Software Developer | Tech Enthusiast | Problem Solver</p>
      </header>

      <main>
        <section className="section">
          <h2>About Me</h2>
          <p>
            Passionate and detail-oriented developer with excellent interpersonal skills.
            I’m reliable, enthusiastic, and eager to grow through knowledge and experience.
          </p>
          <ul>
            <li><strong>Full Name:</strong> Karanja Jeff Kamau</li>
            <li><strong>Date of Birth:</strong> 1st July, 2001</li>
            <li><strong>Nationality:</strong> Kenyan</li>
            <li><strong>Languages:</strong> English, Kiswahili</li>
            <li><strong>Email:</strong> karanjajefferson7@gmail.com</li>
            <li><strong>Phone:</strong> +254799153149</li>
          </ul>
        </section>

        <section className="section">
          <h2>Work Experience</h2>
          <ul>
            <li>Autocom Computers – Sales Agent (Jan 2022 – Sept 2022)</li>
            <li>Seven Sundays – Sales Agent (Feb 2023 – May 2023)</li>
            <li>Call Center International – Call Agent (Aug 2023 – June 2024)</li>
            <li>Mayaash – Safaricom Field Agent (July 2024 – Mar 2025)</li>
          </ul>
        </section>

        <section className="section">
          <h2>Education</h2>
          <ul>
            <li>BSc in Software Development – 2012–2025</li>
            <li>KCSE – Othaya Boys High School (2016–2019)</li>
            <li>KCPE – Josnem Academy (2008–2015)</li>
          </ul>
        </section>

        <section className="section">
          <h2>Skills</h2>
          <ul>
            <li>Communication & Listening</li>
            <li>Teamwork & Collaboration</li>
            <li>Analytical Thinking</li>
            <li>Problem Solving & Decision Making</li>
            <li>MS Office Tools</li>
          </ul>
        </section>

        <section className="section">
          <h2>Certifications & Activities</h2>
          <ul>
            <li>Computer Literacy – KCA University & Essy Cyber</li>
            <li>Peer Counselor – Othaya Boys High School</li>
            <li>National Drama Festivals – Ministry of Education</li>
            <li>Afya Yetu Survey – 2021</li>
            <li>SamaSource LiDAR Training – 2022</li>
          </ul>
        </section>

        <section className="section">
          <h2>Contact</h2>
          <ul>
            <li>Email: <a href="mailto:karanjajefferson7@gmail.com">karanjajefferson7@gmail.com</a></li>
            <li>Phone: <a href="tel:+254799153149">+254 799 153149</a></li>
          </ul>
        </section>
      </main>

      <footer className="footer">
        <p>&copy; 2025 Karanja Developer. All rights reserved.</p>
      </footer>
    </div>
  );
}


// App.css
body {
  margin: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background-color: #f4f4f4;
  color: #333;
}

.App {
  max-width: 1000px;
  margin: auto;
  padding: 20px;
}

.header {
  background-color: #1a1a1a;
  color: white;
  padding: 40px 20px;
  text-align: center;
}

.section {
  padding: 30px 0;
  border-bottom: 1px solid #ddd;
}

.section ul {
  padding-left: 20px;
}

.footer {
  background-color: #222;
  color: white;
  text-align: center;
  padding: 20px;
}

/* Responsive */
@media (max-width: 768px) {
  .App {
    padding: 10px;
  }
  .header h1 {
    font-size: 24px;
  }
  .header p {
    font-size: 16px;
  }
}


// index.css
/* you can keep this file empty or add base styles */
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
