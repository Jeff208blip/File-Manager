# Karanja Developer Portfolio - replit.md

## Overview

This is a personal portfolio website for Karanja Jeff Kamau, a software developer from Kenya. The application is built as a full-stack web application using modern React and Node.js technologies, designed to showcase professional experience, skills, and contact information in an elegant, responsive interface.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **UI Components**: Comprehensive set of Radix UI components for accessibility
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Development**: tsx for TypeScript execution in development
- **Production**: esbuild for server-side bundling

### Database Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development

## Key Components

### Frontend Components
- **Home Page**: Complete portfolio showcase with personal information, work experience, education, and skills
- **UI System**: Full shadcn/ui component library including cards, buttons, forms, dialogs, and navigation
- **Responsive Design**: Mobile-first approach with breakpoint-aware layouts
- **Accessibility**: ARIA-compliant components with keyboard navigation support

### Backend Infrastructure
- **API Foundation**: Express.js server with middleware for logging and error handling
- **Development Server**: Vite integration for hot module replacement in development
- **Static File Serving**: Optimized static asset delivery
- **Environment Configuration**: Separate development and production configurations

### Data Management
- **User Schema**: Basic user model with username/password fields
- **Type Safety**: Full TypeScript integration with Zod validation schemas
- **Storage Abstraction**: Interface-based storage system allowing easy database switching

## Data Flow

1. **Client Requests**: Browser requests routed through Wouter to appropriate React components
2. **API Communication**: Frontend uses TanStack Query for server communication with automatic caching
3. **Server Processing**: Express.js handles API requests and serves static assets
4. **Database Operations**: Drizzle ORM manages database interactions through storage interface
5. **Response Handling**: Type-safe responses with error handling and logging

## External Dependencies

### Core Framework Dependencies
- React ecosystem (React, ReactDOM, React Query)
- Express.js for server framework
- Drizzle ORM with PostgreSQL driver (@neondatabase/serverless)

### UI and Styling
- Tailwind CSS for utility-first styling
- Radix UI components for accessible primitives
- Lucide React for iconography
- Class Variance Authority for component variants

### Development Tools
- Vite for build tooling and development server
- TypeScript for type safety
- ESBuild for production bundling
- Replit-specific plugins for development environment

### Database and Validation
- Drizzle Kit for database management
- Zod for runtime type validation
- PostgreSQL as primary database

## Deployment Strategy

### Development Environment
- **Command**: `npm run dev` - Starts development server with hot reloading
- **Port**: 5000 (automatically configured in Replit)
- **Features**: Vite dev server integration, automatic TypeScript compilation, error overlay

### Production Build
- **Build Process**: `npm run build` - Compiles client assets and bundles server code
- **Client Build**: Vite builds optimized React application to `dist/public`
- **Server Build**: ESBuild bundles server code to `dist/index.js`
- **Start Command**: `npm run start` - Runs production server

### Replit Configuration
- **Modules**: Node.js 20, Web, PostgreSQL 16
- **Auto-deployment**: Configured for autoscale deployment target
- **Port Mapping**: Internal port 5000 mapped to external port 80
- **Workflows**: Parallel execution support for development tasks

## Changelog

```
Changelog:
- June 20, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```